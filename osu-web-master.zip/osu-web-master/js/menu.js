function menu()
{
	log(µ.BM_PAUS);
}
