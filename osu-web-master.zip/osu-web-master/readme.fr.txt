<h1>osu! web</h1>

<div id="share"><a href="https://www.facebook.com/osu.web/"><img src="image/facebook.png" /></a><a href="http://twitter.com/share?text=osu! web – osu! for browsers&url=http://osu-web.com/&via=pictuga"><img src="image/twitter.png" /></a><a href="http://flattr.com/thing/178671/osu-web"><img src="image/flattr.png" /></a><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ECGPQVTWBY22L&item_name=osu%21%20web&currency_code=USD"><img src="image/paypal.png" /></a></div>

<div id="slider"><div id="mask">
	<div data-title="À L'AIDE !!!">
		 - Allumez vos haut-parleurs
		 - Lisez ceci
		 - Cliquez sur le bouton en bas de page
		 - Choisissez une beatmap
		 - Appréciez :)

		<strong>Si vous ne savez pas quelle beatmap choisir, nous vous recommandons "Bad Apple" → "Easy"</strong> ;)
	</div><div data-title="Toujours perdu ?">
		D'accord, je vais essayer de vous expliquer ce que vous êtes sensés faire ici.

		L'idée principale est de cliquer sur les cercles qui apparaissent, en rythme avec la musique, au bon moment. Il y a aussi des "sliders" sur lesquels vous devez faire glisser la balle. Vous pouvez aussi rencontrer des "spinners". Vous devez cliquer dessus et tourner aussi vite que possible !

		Ça peut avoir l'air facile, mais ça peut devenir dur et sympa. Si c'est trop facile à votre goût, choisissez des beatmaps ayant "insane" ou "hard" dans le nom ;)

		Ce site est une version en html5/javascript de osu!
		osu! est un jeu disponible uniquement pour Windows. Ce site a pour but de diffuser le jeu vers d'autres platformes (linux & c), et à terme aux smartphones.
		Le jeu est gratuit, mais nous acceptons les dons !

		<strong>Ce site est encore en développement et peut ne pas fonctionner de temps à autres.</strong>
	</div><div data-title="Raccourcis">
		<span class='key'>F11</span><strong>plein-écran</strong> sur de nombreux navigateurs
		<span class='key'>ESC</span>mettre la partie en <strong>pause</strong>
	</div><div data-title="À propos de nous">
		Fait par <a href='http://pictuga.com/' title='TheCaméléon'>TheCaméléon</a> → <a href='http://twitter.com/pictuga' title='@pictuga'>twitter</a>
		<a href='http://www.pictuga.com/fiche-305.html' title='Project page'>Page du projet</a> - <a href='http://osu.ppy.sh/forum/viewtopic.php?t=36805' title='Forum'>Forum</a> 

		Remerciements à Clemaister et à tous ceux qui ont aidé le projet !

		<a href='http://www.pictuga.com/fiche-363.html' title='On recherche des devs !'>Contribuer</a> – <a href='http://osu.ppy.sh/' title='osu.ppy.sh'>site officiel osu!</a>

		License GPL 3 – Copyright (C) 2010 TheCaméléon
		→ Code source : <a href="https://github.com/pictuga/osu-web">http://github.com/pictuga/osu-web</a>
		N.B. : La version originale du jeu osu! (pour Windows) n'est PAS OpenSource.
	</div>
</div></div>
