<h1>osu! web</h1>

<div id="share"><a href="https://www.facebook.com/osu.web/"><img src="image/facebook.png" /></a><a href="http://twitter.com/share?text=osu! web – osu! for browsers&url=http://osu-web.com/&via=pictuga"><img src="image/twitter.png" /></a><a href="http://flattr.com/thing/178671/osu-web"><img src="image/flattr.png" /></a><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=ECGPQVTWBY22L&item_name=osu%21%20web&currency_code=USD"><img src="image/paypal.png" /></a></div>

<div id="slider"><div id="mask">
	<div data-title="HELP !!!">
		 - Turn on your speakers
		 - Read this
		 - Click on the button at the bottom of the page
		 - Select a beatmap
		 - Enjoy :)
	
		<strong>If you don't know which beatmap to choose, we suggest "Bad Apple" → "Easy"</strong> ;)
	</div><div data-title="Still lost ?">
		Okay, I'll try to explain you what your are supposed to do here.

		The main idea is to click on circles that appear, in rhythm with the music, at the right time. There are also "sliders" on which you have to drag the ball. You can also meet "spinners". You have to click and turn as fast as possible !

		That sounds easy, but it can be really hard and fun at the same time. If it's too easy for you, choose beatmaps with "insane" or "hard" in the name ;)

		This website is a html5/javascript version of osu!
		osu! itself is only available for Windows platform. This website aims to spread the game to other platform (linux & co), and later mobile devices.
		The game is free, but we do accept donations !

		<strong>This website is still in developement and may not work from time to time.</strong>
	</div><div data-title="Shortcuts">
		<span class='key'>F11</span><strong>fullscreen</strong> on a lot of modern browsers
		<span class='key'>ESC</span><strong>pause</strong> the game
	</div><div data-title="About us">
		Made by <a href='http://pictuga.com/' title='TheCaméléon'>TheCaméléon</a> → <a href='http://twitter.com/pictuga' title='@pictuga'>twitter</a>
		<a href='http://www.pictuga.com/fiche-305.html' title='Project page'>Project page</a> - <a href='http://osu.ppy.sh/forum/viewtopic.php?t=36805' title='Forum'>Forum</a> 

		Special thanks to Clemaister and anybody who helped the project !

		<a href='http://www.pictuga.com/fiche-363.html' title='We are looking for devs !'>Contribute</a> – <a href='http://osu.ppy.sh/' title='osu.ppy.sh'>osu! official website</a>

		License GPL 3 – Copyright (C) 2010 TheCaméléon
		→ Source Code : <a href="https://github.com/pictuga/osu-web">http://github.com/pictuga/osu-web</a>
		NB. The original osu! game (for Windows) is NOT OpenSource.
	</div>
</div></div>
